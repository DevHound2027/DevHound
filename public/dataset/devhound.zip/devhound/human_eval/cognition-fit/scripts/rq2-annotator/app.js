"use strict";

const $ = id => document.getElementById(id);
const levels = [
  {name: "Novice", title: "不熟悉", help: "需要背景与推理过程", className: "novice"},
  {name: "Regular", title: "基本理解", help: "需要具体机制与理由", className: "regular"},
  {name: "Expert", title: "熟悉", help: "简洁结论与边界即可", className: "expert"},
];
let dataset, session, currentId, annotations = new Map(), pending = new Map();
let pumping = false, savingError = "", exporting = false, sequence = 0, active = false;
const pointKey = (qid, kid) => JSON.stringify([qid, kid]);
const element = (tag, className, text) => {
  const el = document.createElement(tag);
  if (className) el.className = className;
  if (text !== undefined) el.textContent = text;
  return el;
};
function storageKey() { return `rq2.pending.${dataset.dataset_id}.${session.participant_id}`; }
function positionKey() { return `rq2.position.${dataset.dataset_id}.${session.participant_id}`; }
function cachedSet(key, value) { try { localStorage.setItem(key, value); } catch (_) {   } }
function cachedGet(key) { try { return localStorage.getItem(key); } catch (_) { return null; } }
function rememberPending() {
  cachedSet(storageKey(), JSON.stringify([...pending.values()].map(({id, ...choice}) => choice)));
}
async function request(path, body) {
  const options = body ? {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({...body, dataset_id: dataset.dataset_id})} : {};
  const response = await fetch(path, options);
  if (!response.ok) {
    let message = "连接失败，请检查标注服务是否仍在运行。";
    try { message = (await response.json()).error || message; } catch (_) {}
    throw new Error(message);
  }
  return response;
}
function installState(state) {
  session = state;
  annotations = new Map(state.annotations.map(r => [pointKey(r.question_id, r.keypoint_id), r]));
}
function effective(qid, kid) {
  const key = pointKey(qid, kid);
  return pending.has(key) ? pending.get(key).level : annotations.get(key)?.level || null;
}
function questionCount(question) {
  return question.keypoints.filter(kp => effective(question.question_id, kp.id)).length;
}
function visibleQuestions() {
  const term = $("search").value.trim().toLowerCase();
  return dataset.questions.filter(q => {
    if ($("repo-filter").value && q.repository !== $("repo-filter").value) return false;
    if (term && !`${q.question_id} ${q.question}`.toLowerCase().includes(term)) return false;
    const done = questionCount(q) === q.keypoints.length;
    return $("status-filter").value === "all" || ($("status-filter").value === "complete" ? done : !done);
  });
}
function renderSidebar() {
  const fragment = document.createDocumentFragment();
  for (const q of visibleQuestions()) {
    const count = questionCount(q), done = count === q.keypoints.length;
    const button = element("button", `question-link${q.question_id === currentId ? " active" : ""}${done ? " done" : ""}`);
    button.type = "button";
    button.setAttribute("aria-label", `${q.question_id}，已选 ${count}/${q.keypoints.length}`);
    if (q.question_id === currentId) button.setAttribute("aria-current", "step");
    button.append(element("span", "question-dot", done ? "✓" : q.number), element("span", "question-link-id", q.question_id), element("span", "question-count", `${count}/${q.keypoints.length}`));
    button.addEventListener("click", () => showQuestion(q.question_id));
    fragment.append(button);
  }
  if (!fragment.childNodes.length) fragment.append(element("p", "empty-list", "没有符合筛选条件的题目。"));
  $("question-list").replaceChildren(fragment);
}
function renderStatus() {
  if (!session) return;
  const total = dataset.keypoint_count;
  const selected = dataset.questions.reduce((n, q) => n + questionCount(q), 0);
  const completeQuestions = dataset.questions.filter(q => questionCount(q) === q.keypoints.length).length;
  const ready = annotations.size === total && pending.size === 0 && !pumping && !savingError;
  $("progress-number").textContent = selected;
  $("progress-denominator").textContent = `/ ${total} KP`;
  $("progress-bar").max = total; $("progress-bar").value = selected;
  $("question-progress").textContent = `已选完 ${completeQuestions} / ${dataset.question_count} 道题`;
  $("save-status").textContent = savingError ? savingError : pumping || pending.size ? `正在保存 · ${pending.size} 项待确认` : `已保存 ${annotations.size} / ${total} KP`;
  $("save-status").classList.toggle("failed", Boolean(savingError));
  $("retry-save").hidden = !savingError;
  $("export-button").disabled = !ready || exporting;
  $("backup-button").disabled = exporting || pumping || pending.size > 0;
  $("restore-button").disabled = exporting || pumping || pending.size > 0;
  $("completion-card").hidden = !ready;
  $("export-hint").textContent = ready ? `已保存全部 ${total} 个 KP。确认后导出你的个人 JSONL 结果。` : `已保存 ${annotations.size} / ${total} 个 KP；完整结果需要全部填写并保存。也可先导出进度备份。`;
  const q = dataset.questions.find(q => q.question_id === currentId);
  if (q) {
    $("current-question-progress").textContent = `本题已选 ${questionCount(q)} / ${q.keypoints.length} 个 KP`;
    $("page-hint").textContent = questionCount(q) < q.keypoints.length ? `本题还有 ${q.keypoints.length - questionCount(q)} 项未选，可稍后补充` : "本题已选完，可继续下一题";
  }
  const shown = visibleQuestions(), index = shown.findIndex(q => q.question_id === currentId);
  $("previous-question").disabled = shown.length === 0 || index <= 0;
  $("next-question").disabled = shown.length === 0 || index === shown.length - 1;
  renderSidebar();
}
function updatePointCard(kid) {
  const card = [...$("keypoints").children].find(c => c.dataset.keypointId === kid);
  if (!card) return;
  const selected = effective(currentId, kid);
  const unsaved = pending.has(pointKey(currentId, kid));
  card.classList.toggle("answered", Boolean(selected));
  card.querySelector(".point-status").textContent = selected ? unsaved ? "待保存" : "已保存" : "待选择";
  for (const input of card.querySelectorAll("input[type=radio]")) {
    input.checked = input.value === selected;
    input.closest("label").classList.toggle("chosen", input.checked);
  }
  card.querySelector(".clear-choice").disabled = !selected;
}
function showQuestion(id, scroll = true) {
  const q = dataset.questions.find(q => q.question_id === id);
  if (!q) return;
  currentId = id;
  cachedSet(positionKey(), id);
  $("question-position").textContent = `QUESTION ${String(q.number).padStart(3, "0")} / ${dataset.question_count}`;
  $("question-repo").textContent = q.repository;
  $("question-type").textContent = q.question_type;
  $("question-id").textContent = q.question_id;
  $("question-text").textContent = q.question;
  const fragment = document.createDocumentFragment();
  q.keypoints.forEach((kp, index) => {
    const card = element("fieldset", "point-card"); card.dataset.keypointId = kp.id;
    const legend = element("legend", "sr-only", `${q.question_id} ${kp.id} 的认知等级`); card.append(legend);
    const head = element("div", "point-header");
    head.append(element("span", "kp-tag", kp.id), element("span", "point-status", "待选择"));
    const clear = element("button", "text-button clear-choice", "清空此项"); clear.type = "button";
    clear.addEventListener("click", () => stage(q.question_id, kp.id, null)); head.append(clear);
    card.append(head, element("p", "point-description", kp.description));
    const choices = element("div", "choices");
    for (const level of levels) {
      const label = element("label", `choice ${level.className}`);
      const input = document.createElement("input"); input.type = "radio";
      input.name = `level-${q.number}-${index}`; input.value = level.name;
      input.setAttribute("aria-label", `${kp.id} ${level.name} ${level.title}`);
      input.addEventListener("change", () => { if (input.checked) stage(q.question_id, kp.id, level.name); });
      const title = element("span", "choice-title"); title.append(element("span", "radio-mark"), element("strong", "", level.name), element("span", "choice-subtitle", level.title));
      label.append(input, title, element("span", "choice-help", level.help)); choices.append(label);
    }
    card.append(choices); fragment.append(card);
  });
  $("keypoints").replaceChildren(fragment);
  q.keypoints.forEach(kp => updatePointCard(kp.id)); renderStatus();
  if (scroll) window.scrollTo({top: 0, behavior: "smooth"});
}
function stage(qid, kid, level) {
  const key = pointKey(qid, kid);
  pending.set(key, {id: ++sequence, question_id: qid, keypoint_id: kid, level, client_selected_at: new Date().toISOString()});
  rememberPending(); updatePointCard(kid); renderStatus();
  if (!savingError) void pump();
}
async function pump() {
  if (pumping || savingError) return;
  pumping = true; renderStatus();
  try {
    while (pending.size) {
      const [key, choice] = pending.entries().next().value;
      const response = await request("/api/annotation", {...choice, participant_id: session.participant_id, revision: session.revision});
      const result = await response.json(); session.revision = result.revision;
      if (result.annotation) annotations.set(key, result.annotation); else annotations.delete(key);
      if (pending.get(key)?.id === choice.id) pending.delete(key);
      rememberPending();
      if (choice.question_id === currentId) updatePointCard(choice.keypoint_id);
      renderStatus();
    }
  } catch (error) {
    savingError = error.message || "保存失败，请重试。";
  } finally { pumping = false; renderStatus(); }
}
async function retry() {
  $("retry-save").disabled = true;
  try {
    const response = await request(`/api/state?participant_id=${encodeURIComponent(session.participant_id)}`);
    installState(await response.json()); savingError = "";
    showQuestion(currentId, false); await pump();
  } catch (error) { savingError = error.message; renderStatus(); }
  finally { $("retry-save").disabled = false; }
}
async function start(pid) {
  $("start-button").disabled = true; $("welcome-error").textContent = "";
  try {
    const response = await request("/api/session", {participant_id: pid}); installState(await response.json());
    pending = new Map(); savingError = "";
    try {
      const cached = JSON.parse(cachedGet(storageKey()) || "[]");
      for (const c of cached) {
        const q = dataset.questions.find(q => q.question_id === c.question_id);
        if (q?.keypoints.some(k => k.id === c.keypoint_id) && (c.level === null || levels.some(l => l.name === c.level)) && typeof c.client_selected_at === "string") {
          pending.set(pointKey(c.question_id, c.keypoint_id), {...c, id: ++sequence});
        }
      }
    } catch (_) {   }
    active = true;
    try { sessionStorage.setItem("rq2.active", pid); } catch (_) {}
    $("welcome").hidden = true; $("workspace").hidden = false;
    $("participant-badge").textContent = pid; $("participant-badge").hidden = false;
    $("switch-participant").hidden = false;
    const savedPosition = cachedGet(positionKey());
    const firstMissing = dataset.questions.find(q => questionCount(q) < q.keypoints.length);
    showQuestion(dataset.questions.some(q => q.question_id === savedPosition) ? savedPosition : (firstMissing || dataset.questions[0]).question_id, false);
    await pump();
  } catch (error) { $("welcome-error").textContent = error.message; }
  finally { $("start-button").disabled = false; }
}
async function download(kind) {
  exporting = true; renderStatus(); $("action-message").textContent = "正在准备导出…";
  try {
    const response = await request("/api/export", {participant_id: session.participant_id, revision: session.revision, kind});
    const filename = response.headers.get("Content-Disposition")?.match(/filename="([^"]+)"/)?.[1] || `${session.participant_id}_rq2.jsonl`;
    const blob = await response.blob(), url = URL.createObjectURL(blob);
    const link = document.createElement("a"); link.href = url; link.download = filename; document.body.append(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30_000);
    $("action-message").textContent = kind === "final" ? "完整结果已导出。浏览器下载目录和服务端导出目录各保留一份。" : "进度备份已导出；下次也可以用“恢复进度”导入。";
  } catch (error) { $("action-message").textContent = error.message; }
  finally { exporting = false; renderStatus(); }
}
async function restore(file) {
  if (!file) return;
  try {
    if (file.size > 4_000_000) throw new Error("备份文件过大。请使用本工具导出的进度文件。");
    const backup = JSON.parse(await file.text());
    if (backup.dataset_id !== dataset.dataset_id || backup.participant_id !== session.participant_id) throw new Error("备份的题库版本或受试者编号不一致。");
    if (!confirm("恢复会合并备份中的选择，并覆盖相同 KP 的已有选择。是否继续？")) return;
    const response = await request("/api/restore", {participant_id: session.participant_id, revision: session.revision, backup});
    installState(await response.json()); showQuestion(currentId, false);
    $("action-message").textContent = `已恢复备份，当前保存 ${annotations.size} 个 KP。`;
  } catch (error) { $("action-message").textContent = `恢复失败：${error.message}`; }
  finally { $("restore-file").value = ""; }
}
function filterChanged() {
  const visible = visibleQuestions();
  if (visible.length && !visible.some(q => q.question_id === currentId)) showQuestion(visible[0].question_id);
  else renderStatus();
}
function navigate(delta) {
  const visible = visibleQuestions(), index = visible.findIndex(q => q.question_id === currentId);
  const next = index < 0 ? visible[0] : visible[index + delta];
  if (next) showQuestion(next.question_id);
}
async function init() {
  try {
    const response = await fetch("/api/dataset"); if (!response.ok) throw new Error("题库读取失败。");
    dataset = await response.json();
    $("dataset-size").textContent = `${dataset.question_count} 道题 · ${dataset.keypoint_count} 个 KP`;
    for (const pid of dataset.participants) { const option = element("option", "", pid); option.value = pid; $("participant-select").append(option); }
    for (const repo of [...new Set(dataset.questions.map(q => q.repository))]) { const option = element("option", "", repo); option.value = repo; $("repo-filter").append(option); }
    $("start-button").disabled = false;
    let remembered; try { remembered = sessionStorage.getItem("rq2.active"); } catch (_) {}
    if (dataset.participants.includes(remembered)) await start(remembered);
  } catch (error) { $("welcome-error").textContent = `无法加载：${error.message}`; }
}
$("start-form").addEventListener("submit", event => { event.preventDefault(); if ($("participant-select").value) void start($("participant-select").value); });
$("switch-participant").addEventListener("click", async () => {
  await pump();
  if (pumping || pending.size) { $("action-message").textContent = "仍有待保存的选择，请先完成保存或重试，再切换编号。"; return; }
  active = false; try { sessionStorage.removeItem("rq2.active"); } catch (_) {}
  $("welcome").hidden = false; $("workspace").hidden = true;
  $("participant-badge").hidden = true; $("switch-participant").hidden = true;
  $("participant-select").value = ""; $("action-message").textContent = "";
});
$("retry-save").addEventListener("click", retry);
$("previous-question").addEventListener("click", () => navigate(-1));
$("next-question").addEventListener("click", () => navigate(1));
$("jump-missing").addEventListener("click", () => {
  const start = dataset.questions.findIndex(q => q.question_id === currentId);
  const ordered = [...dataset.questions.slice(start + 1), ...dataset.questions.slice(0, start + 1)];
  const missing = ordered.find(q => questionCount(q) < q.keypoints.length);
  if (missing) {
    $("search").value = ""; $("repo-filter").value = ""; $("status-filter").value = "all";
    showQuestion(missing.question_id);
  } else { $("action-message").textContent = "全部 KP 已选择，请检查保存状态后导出。"; }
});
$("search").addEventListener("input", filterChanged);
$("repo-filter").addEventListener("change", filterChanged);
$("status-filter").addEventListener("change", filterChanged);
$("rubric-button").addEventListener("click", () => $("rubric-dialog").showModal());
$("close-rubric").addEventListener("click", () => $("rubric-dialog").close());
$("backup-button").addEventListener("click", () => download("backup"));
$("export-button").addEventListener("click", () => download("final"));
$("restore-button").addEventListener("click", () => $("restore-file").click());
$("restore-file").addEventListener("change", () => restore($("restore-file").files[0]));
window.addEventListener("beforeunload", event => {
  if (active && (pumping || pending.size)) { event.preventDefault(); event.returnValue = ""; }
});
void init();
