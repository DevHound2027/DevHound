#!/usr/bin/env python3

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sqlite3
import sys
import threading
import webbrowser
from contextlib import contextmanager
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

ROOT = Path(__file__).resolve().parents[1]
ASSETS = Path(__file__).resolve().parent / "rq2-annotator"
LEVELS = ("Novice", "Regular", "Expert")
PROTOCOL = "question_and_reference_keypoints_visible_self_report_v1"
RESULT_FIELDS = (
    "schema_version", "dataset_id", "participant_id", "question_id", "keypoint_id",
    "repository", "question_type", "cognitive_level",
)


class Invalid(ValueError):
    pass


class Conflict(Invalid):
    pass


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def json_bytes(value) -> bytes:
    return (json.dumps(value, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")


def participant(value) -> str:
    if not isinstance(value, str) or not re.fullmatch(r"P(?:[1-9]|10)", value):
        raise Invalid("请选择 P1–P10 中的受试者编号。")
    return value


def timestamp(value) -> str:
    if not isinstance(value, str):
        raise Invalid("选择时间格式不正确。")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise Invalid("选择时间格式不正确。") from exc
    if parsed.tzinfo is None:
        raise Invalid("选择时间必须包含时区。")
    return parsed.astimezone(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


class Dataset:
    def __init__(self, directory: Path):
        self.directory = directory.resolve()
        self.source = {}
        collections = []
        for filename in ("qa_eval.jsonl", "qa_gold.jsonl"):
            path = self.directory / filename
            try:
                raw = path.read_bytes()
                rows = [json.loads(line) for line in raw.decode("utf-8-sig").splitlines() if line.strip()]
            except (OSError, ValueError, UnicodeError) as exc:
                raise Invalid(f"无法读取 {path}: {exc}") from exc
            if not rows or not all(isinstance(row, dict) for row in rows):
                raise Invalid(f"{filename} 必须包含非空的 JSON 对象记录。")
            self.source[filename] = {"path": str(path), "sha256": digest(raw)}
            collections.append(rows)
        evals, golds = collections
        for filename, rows in zip(self.source, collections):
            ids = [row.get("question_id") for row in rows]
            if not all(isinstance(qid, str) and qid for qid in ids) or len(ids) != len(set(ids)):
                raise Invalid(f"{filename} 存在空或重复的 question_id。")
        gold_index = {row["question_id"]: row for row in golds}
        if {row["question_id"] for row in evals} != set(gold_index):
            raise Invalid("qa_eval 和 qa_gold 的题目 ID 集合不一致。")
        self.questions = []
        self.points = {}
        self.question_index = {}
        for row in evals:
            qid = row["question_id"]
            gold = gold_index[qid]
            if not isinstance(row.get("question"), str) or not row["question"].strip():
                raise Invalid(f"{qid} 缺少题面。")
            for field in ("repository", "question_type"):
                if row.get(field) != gold.get(field) or not isinstance(row.get(field), str):
                    raise Invalid(f"{qid} 的 {field} 不一致或缺失。")
            kps = gold.get("correctness_keypoints")
            if not isinstance(kps, list) or not kps:
                raise Invalid(f"{qid} 缺少 correctness_keypoints。")
            points = []
            for kp in kps:
                if not isinstance(kp, dict):
                    raise Invalid(f"{qid} 的 KP 不是对象。")
                kid, description = kp.get("id"), kp.get("description")
                if not isinstance(kid, str) or not kid or not isinstance(description, str) or not description.strip():
                    raise Invalid(f"{qid} 存在空 KP ID 或内容。")
                if (qid, kid) in self.points:
                    raise Invalid(f"{qid} 存在重复 KP ID: {kid}")
                point = {"id": kid, "description": description}
                points.append(point)
                self.points[qid, kid] = point
            question = {"question_id": qid, "repository": row["repository"],
                        "question_type": row["question_type"], "language": row.get("language", "unknown"),
                        "question": row["question"], "keypoints": points, "number": len(self.questions) + 1}
            self.questions.append(question)
            self.question_index[qid] = question

        self.id = digest(json_bytes({name: info["sha256"] for name, info in self.source.items()}))

    def public(self) -> dict:
        return {"dataset_id": self.id, "questions": self.questions,
                "question_count": len(self.questions), "keypoint_count": len(self.points),
                "participants": [f"P{i}" for i in range(1, 11)],
                "source_directory": self.directory.name, "protocol": PROTOCOL}


class Store:
    def __init__(self, dataset: Dataset, directory: Path):
        self.dataset = dataset
        self.directory = directory.resolve()
        self.directory.mkdir(parents=True, exist_ok=True)
        self.db_path = self.directory / "annotations.sqlite3"
        self.export_dir = self.directory / dataset.id[:16] / "exports"
        self.export_dir.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.executescript("""
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS sessions (
                    dataset_id TEXT NOT NULL, participant_id TEXT NOT NULL,
                    revision INTEGER NOT NULL DEFAULT 0, started_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL, last_export_at TEXT,
                    PRIMARY KEY (dataset_id, participant_id));
                CREATE TABLE IF NOT EXISTS annotations (
                    dataset_id TEXT NOT NULL, participant_id TEXT NOT NULL,
                    question_id TEXT NOT NULL, keypoint_id TEXT NOT NULL,
                    level TEXT NOT NULL CHECK(level IN ('Novice','Regular','Expert')),
                    client_selected_at TEXT NOT NULL, saved_at TEXT NOT NULL,
                    PRIMARY KEY (dataset_id, participant_id, question_id, keypoint_id));
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, dataset_id TEXT NOT NULL,
                    participant_id TEXT NOT NULL, question_id TEXT NOT NULL,
                    keypoint_id TEXT NOT NULL, old_level TEXT, new_level TEXT,
                    client_selected_at TEXT NOT NULL, saved_at TEXT NOT NULL);
            """)
        manifest = self.directory / dataset.id[:16] / "dataset.json"
        if not manifest.exists():
            manifest.write_bytes(json_bytes({"dataset_id": dataset.id, "source": dataset.source,
                                             "question_count": len(dataset.questions), "keypoint_count": len(dataset.points),
                                             "annotation_protocol": PROTOCOL}))

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.db_path, timeout=15, isolation_level=None)
        db.row_factory = sqlite3.Row
        try:
            yield db
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    def _session(self, db, pid):
        session = db.execute("SELECT * FROM sessions WHERE dataset_id=? AND participant_id=?", (self.dataset.id, pid)).fetchone()
        if session is None:
            raise Invalid("请先选择受试者编号并开始标注。")
        return session

    def _state(self, db, pid):
        session = self._session(db, pid)
        rows = db.execute("SELECT question_id,keypoint_id,level,client_selected_at,saved_at FROM annotations WHERE dataset_id=? AND participant_id=?", (self.dataset.id, pid)).fetchall()
        return {"dataset_id": self.dataset.id, "participant_id": pid, "revision": session["revision"],
                "started_at": session["started_at"], "updated_at": session["updated_at"],
                "last_export_at": session["last_export_at"], "annotations": [dict(r) for r in rows],
                "saved_count": len(rows), "total_count": len(self.dataset.points)}

    def session(self, pid):
        participant(pid)
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            t = now()
            db.execute("INSERT OR IGNORE INTO sessions(dataset_id,participant_id,started_at,updated_at) VALUES(?,?,?,?)", (self.dataset.id, pid, t, t))
            result = self._state(db, pid)
            db.commit()
            return result

    def state(self, pid):
        participant(pid)
        with self.connect() as db:
            db.execute("BEGIN")
            return self._state(db, pid)

    def _check_revision(self, session, revision):
        if type(revision) is not int or revision < 0:
            raise Invalid("缺少有效的保存版本，请重新载入页面。")
        if revision != session["revision"]:
            raise Conflict("该受试者编号已在另一窗口更新。当前待保存选择仍保留，请点击重试。")

    def save(self, data):
        pid = participant(data.get("participant_id"))
        qid, kid, level = data.get("question_id"), data.get("keypoint_id"), data.get("level")
        if not isinstance(qid, str) or not isinstance(kid, str) or (qid, kid) not in self.dataset.points:
            raise Invalid("题目或 KP 不属于当前数据集。")
        if level is not None and level not in LEVELS:
            raise Invalid("每个 KP 只能选择 Novice、Regular 或 Expert。")
        selected_at = timestamp(data.get("client_selected_at"))
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            session = self._session(db, pid)
            self._check_revision(session, data.get("revision"))
            old = db.execute("SELECT level,client_selected_at FROM annotations WHERE dataset_id=? AND participant_id=? AND question_id=? AND keypoint_id=?", (self.dataset.id, pid, qid, kid)).fetchone()
            saved_at = now()
            if level is None:
                db.execute("DELETE FROM annotations WHERE dataset_id=? AND participant_id=? AND question_id=? AND keypoint_id=?", (self.dataset.id, pid, qid, kid))
            else:
                db.execute("INSERT INTO annotations VALUES(?,?,?,?,?,?,?) ON CONFLICT(dataset_id,participant_id,question_id,keypoint_id) DO UPDATE SET level=excluded.level,client_selected_at=excluded.client_selected_at,saved_at=excluded.saved_at", (self.dataset.id, pid, qid, kid, level, selected_at, saved_at))
            db.execute("INSERT INTO events(dataset_id,participant_id,question_id,keypoint_id,old_level,new_level,client_selected_at,saved_at) VALUES(?,?,?,?,?,?,?,?)", (self.dataset.id, pid, qid, kid, old["level"] if old else None, level, selected_at, saved_at))
            db.execute("UPDATE sessions SET revision=revision+1,updated_at=? WHERE dataset_id=? AND participant_id=?", (saved_at, self.dataset.id, pid))
            result = {"revision": session["revision"] + 1, "question_id": qid, "keypoint_id": kid,
                      "annotation": {"question_id": qid, "keypoint_id": kid, "level": level,
                                     "client_selected_at": selected_at, "saved_at": saved_at} if level else None}
            db.commit()
            return result

    def export(self, data):
        pid = participant(data.get("participant_id"))
        kind = data.get("kind", "final")
        if kind not in {"final", "backup"}:
            raise Invalid("未知导出类型。")
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            session = self._session(db, pid)
            self._check_revision(session, data.get("revision"))
            state = self._state(db, pid)
            by_key = {(r["question_id"], r["keypoint_id"]): r for r in state["annotations"]}
            complete = len(by_key) == len(self.dataset.points)
            if kind == "final" and not complete:
                missing = len(self.dataset.points) - len(by_key)
                raise Conflict(f"还有 {missing} 个 KP 未标注，不能导出完整结果。可先导出进度备份。")
            exported_at = now()
            records = []
            for question in self.dataset.questions:
                for kp in question["keypoints"]:
                    record = by_key.get((question["question_id"], kp["id"]))
                    if not record:
                        continue
                    records.append({
                        "schema_version": 1, "dataset_id": self.dataset.id,
                        "participant_id": pid, "question_id": question["question_id"], "keypoint_id": kp["id"],
                        "repository": question["repository"], "question_type": question["question_type"],
                        "cognitive_level": record["level"], "label_source": "participant_self_report",
                        "annotation_protocol": PROTOCOL,
                        "annotated_at": record["client_selected_at"], "server_saved_at": record["saved_at"],
                        "state_reference_time": record["client_selected_at"],
                        "state_reference_time_source": "browser_selection_clock",
                        "participant_confirmed": kind == "final", "confirmed_at": exported_at if kind == "final" else None,
                        "annotation_status": "confirmed_self_report" if kind == "final" else "draft_self_report",
                        "exported_at": exported_at, "export_revision": state["revision"],
                        "source_eval_sha256": self.dataset.source["qa_eval.jsonl"]["sha256"],
                        "source_gold_sha256": self.dataset.source["qa_gold.jsonl"]["sha256"],
                    })
            if kind == "final":

                body = b"".join(json_bytes({field: r[field] for field in RESULT_FIELDS}) for r in records)
                extension, content_type = "jsonl", "application/x-ndjson; charset=utf-8"
            else:
                body = json_bytes({"schema_version": 1, "export_kind": "rq2_annotation_progress",
                                   "dataset_id": self.dataset.id, "participant_id": pid,
                                   "revision": state["revision"], "exported_at": exported_at,
                                   "source": self.dataset.source, "complete": complete, "annotations": records})
                extension, content_type = "progress.json", "application/json; charset=utf-8"
            stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
            name = f"{pid}_rq2_{self.dataset.id[:12]}_r{state['revision']}_{stamp}.{extension}"
            path = self.export_dir / name

            with path.open("xb") as f:
                f.write(body)
            db.execute("UPDATE sessions SET last_export_at=? WHERE dataset_id=? AND participant_id=?", (exported_at, self.dataset.id, pid))
            db.commit()
            return name, content_type, body

    def restore(self, data):
        pid = participant(data.get("participant_id"))
        backup = data.get("backup")
        if not isinstance(backup, dict) or backup.get("export_kind") != "rq2_annotation_progress" or backup.get("schema_version") != 1:
            raise Invalid("请选择本工具导出的 .progress.json 进度备份。")
        if backup.get("dataset_id") != self.dataset.id or backup.get("participant_id") != pid:
            raise Invalid("备份的数据集版本或受试者编号与当前会话不一致。")
        rows = backup.get("annotations")
        if not isinstance(rows, list):
            raise Invalid("备份缺少标注列表。")
        validated, seen = [], set()
        for row in rows:
            if not isinstance(row, dict):
                raise Invalid("备份含有无效记录。")
            qid, kid, level = row.get("question_id"), row.get("keypoint_id"), row.get("cognitive_level")
            if not isinstance(qid, str) or not isinstance(kid, str) or (qid, kid) not in self.dataset.points or (qid, kid) in seen:
                raise Invalid("备份含有未知或重复 KP。")
            if row.get("participant_id") != pid or row.get("dataset_id") != self.dataset.id or row.get("label_source") != "participant_self_report" or row.get("annotation_protocol") != PROTOCOL or level not in LEVELS:
                raise Invalid("备份记录的来源、编号或标签不正确。")
            seen.add((qid, kid))
            validated.append((qid, kid, level, timestamp(row.get("annotated_at"))))
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            self._check_revision(self._session(db, pid), data.get("revision"))
            saved_at = now()
            for qid, kid, level, selected_at in validated:
                old = db.execute("SELECT level FROM annotations WHERE dataset_id=? AND participant_id=? AND question_id=? AND keypoint_id=?", (self.dataset.id, pid, qid, kid)).fetchone()
                db.execute("INSERT INTO annotations VALUES(?,?,?,?,?,?,?) ON CONFLICT(dataset_id,participant_id,question_id,keypoint_id) DO UPDATE SET level=excluded.level,client_selected_at=excluded.client_selected_at,saved_at=excluded.saved_at", (self.dataset.id, pid, qid, kid, level, selected_at, saved_at))
                db.execute("INSERT INTO events(dataset_id,participant_id,question_id,keypoint_id,old_level,new_level,client_selected_at,saved_at) VALUES(?,?,?,?,?,?,?,?)", (self.dataset.id, pid, qid, kid, old["level"] if old else None, level, selected_at, saved_at))
            db.execute("UPDATE sessions SET revision=revision+1,updated_at=? WHERE dataset_id=? AND participant_id=?", (saved_at, self.dataset.id, pid))
            result = self._state(db, pid)
            db.commit()
            return result


def make_server(dataset: Dataset, store: Store, host: str, port: int):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def send(self, status, body, content_type="application/json; charset=utf-8", filename=None):
            if not isinstance(body, bytes):
                body = json_bytes(body)
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'")
            if filename:
                self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            parsed = urlsplit(self.path)
            try:
                if parsed.path == "/api/dataset":
                    self.send(200, dataset.public())
                elif parsed.path == "/api/state":
                    self.send(200, store.state(parse_qs(parsed.query).get("participant_id", [None])[0]))
                elif parsed.path in {"/", "/index.html", "/app.js", "/style.css"}:
                    filename = "index.html" if parsed.path == "/" else parsed.path[1:]
                    mime = {"index.html": "text/html; charset=utf-8", "app.js": "text/javascript; charset=utf-8", "style.css": "text/css; charset=utf-8"}[filename]
                    self.send(200, (ASSETS / filename).read_bytes(), mime)
                elif parsed.path == "/favicon.ico":
                    self.send(204, b"", "image/x-icon")
                else:
                    self.send(404, {"error": "未找到页面。"})
            except Invalid as exc:
                self.send(400, {"error": str(exc)})
            except (OSError, sqlite3.Error) as exc:
                self.send(500, {"error": f"读取失败：{exc}"})

        def do_POST(self):
            try:
                origin = self.headers.get("Origin")
                if origin and (urlsplit(origin).netloc != self.headers.get("Host") or urlsplit(origin).scheme not in {"http", "https"}):
                    raise Invalid("请从本标注页面提交数据。")
                if self.headers.get_content_type() != "application/json":
                    raise Invalid("请求必须使用 JSON 格式。")
                length = int(self.headers.get("Content-Length", "0"))
                if not 0 < length <= 4_000_000:
                    raise Invalid("请求为空或超过大小限制。")
                data = json.loads(self.rfile.read(length))
                if not isinstance(data, dict):
                    raise Invalid("请求必须是 JSON 对象。")
                if data.get("dataset_id") != dataset.id:
                    raise Conflict("数据集版本已经变化，请重新载入页面。")
                path = urlsplit(self.path).path
                if path == "/api/session":
                    self.send(200, store.session(data.get("participant_id")))
                elif path == "/api/annotation":
                    self.send(200, store.save(data))
                elif path == "/api/restore":
                    self.send(200, store.restore(data))
                elif path == "/api/export":
                    filename, mime, body = store.export(data)
                    self.send(200, body, mime, filename)
                else:
                    self.send(404, {"error": "未找到接口。"})
            except Conflict as exc:
                self.send(409, {"error": str(exc)})
            except (Invalid, ValueError, TypeError, OverflowError) as exc:
                self.send(400, {"error": str(exc)})
            except (OSError, sqlite3.Error) as exc:
                self.send(500, {"error": f"保存失败，已有数据保留：{exc}"})

    return ThreadingHTTPServer((host, port), Handler)


def main():
    parser = argparse.ArgumentParser(description='Local RQ2 participant annotation app. Python 3.10+, standard library only.')
    parser.add_argument("--dataset-dir", type=Path, default=ROOT / "input", help="含 qa_eval.jsonl / qa_gold.jsonl 的目录")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "results/collected", help="自动保存和导出目录")
    parser.add_argument("--host", default="127.0.0.1", help="监听地址；局域网共用可设为 0.0.0.0")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--no-browser", action="store_true", help="不自动打开浏览器")
    parser.add_argument("--check", action="store_true", help="只检查输入数据，不启动服务或写入进度")
    args = parser.parse_args()
    try:
        dataset = Dataset(args.dataset_dir.expanduser())
        if args.check:
            print(json.dumps({"valid": True, "dataset_id": dataset.id, "questions": len(dataset.questions), "keypoints": len(dataset.points), "source": dataset.source}, ensure_ascii=False, indent=2))
            return
        store = Store(dataset, args.output_dir.expanduser())
        server = make_server(dataset, store, args.host, args.port)
    except (Invalid, OSError, sqlite3.Error) as exc:
        parser.exit(1, f"启动失败：{exc}\n")
    local_host = "127.0.0.1" if args.host == "0.0.0.0" else args.host
    url = f"http://{local_host}:{server.server_port}"
    print(f"RQ2 标注页面：{url}\n数据：{dataset.directory}\n题目：{len(dataset.questions)}，KP：{len(dataset.points)}\n自动保存：{store.db_path}\n导出：{store.export_dir}\n停止服务：Ctrl+C", flush=True)
    if args.host == "0.0.0.0":
        print(f"局域网受试者可访问 http://本机局域网IP:{server.server_port}；P1–P10 是选择编号，不是身份认证。", flush=True)
    if not args.no_browser:
        threading.Timer(0.4, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n服务已停止；已保存进度将在下次运行时恢复。")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
