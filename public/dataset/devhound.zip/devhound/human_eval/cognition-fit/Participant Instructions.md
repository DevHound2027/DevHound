# Cognitive Need Annotation for Knowledge Points: Participant Instructions

Thank you for participating in this study. Please read the following instructions before starting the annotation.

## Study Objective

This study aims to understand what explanations of background knowledge, mechanisms, or decision rationales different developers need when answering the same software repository question, as well as the appropriate level of explanation depth. Your self-assessments of individual knowledge points will serve as participant-specific reference labels for evaluating DevHound's ability to predict developers' cognitive needs.

The annotation interface presents a question and the key points (**KPs**) of its reference answer. Based on your actual understanding after reading the question and each KP, please assign a level to every KP. We are collecting your self-assessment at the time of annotation, so please reflect your own needs accurately.

## Choosing Among the Three Levels

| Level | Your Understanding and Explanation Needs |
|---|---|
| **Novice (Unfamiliar)** | You are unfamiliar with the knowledge point and need background concepts and a step-by-step explanation of the underlying mechanisms or reasoning. |
| **Regular (Basic Understanding)** | You have relevant foundational knowledge but need an explanation focused on the specific implementation, component interactions, or decision rationale in this repository. |
| **Expert (Familiar)** | You can independently explain the knowledge point, and a concise conclusion, its applicable boundaries, and supporting evidence are sufficient for your needs. |

For example, suppose a KP states that "after a configuration change, the component clears the old cache and reloads." If you first need to understand caching and cache invalidation mechanisms, select **Novice**. If you understand caching principles but need to know where this repository triggers cache clearing and reloading, select **Regular**. If you can independently explain the entire process and its boundaries, select **Expert**.

The same participant may select different levels across repositories, questions, and even KPs within the same question. Please assess each KP independently, without trying to maintain any particular distribution of labels. Even if a technology belongs to your primary technology stack, base your selection on your familiarity with the specific knowledge point.

## Getting Started

The researcher will assign you a fixed participant ID (**P1–P10**). Always use your assigned ID and perform annotations in only one browser window at a time.

- **If the researcher provides a website URL:** Open the URL, select your participant ID, and click "Start / Resume Annotation."
- **If the researcher provides a local tool folder:** Python 3.10 or later is required, with no additional dependencies. Open a terminal, navigate to the provided `rq2` folder, and run:

```bash
python3 scripts/annotate-rq2.py
```

Your browser will open automatically. Alternatively, you can manually visit http://127.0.0.1:8765. Keep the terminal running while using the local tool.

If the researcher provides a Chinese version of the question set, follow the unified startup command provided by the researcher. All participants should use the same question set version within a given annotation round.

## Annotation Procedure

1. **Read the question.** Understand the repository, the question being asked, and its context.

2. **Review each KP.** For each KP, select one level: Novice, Regular, or Expert. Make your selection independently based on your own understanding and explanation needs. There is no need to consult external resources or seek assistance from others solely for annotation purposes.

3. **Confirm that your selection is saved.** Selections are saved automatically, and the save status is displayed in the upper-right corner. You may change your selection at any time or click "Clear This Item" to reassess it.

4. **Proceed to the next question.** Use the "Previous / Next" buttons or the question list on the left to navigate. You can also search for questions, filter by repository or completion status, or click "Go to Next Incomplete Question."

5. **Check for missing annotations.** The left panel displays the number of annotated KPs and completed questions. The "Confirm and Export Complete Results" button will become available only after all **744 KPs** have been assigned a level and successfully saved.

6. **Export and submit your results.** After reviewing your selections, click "Confirm and Export Complete Results." Your browser will download a `.jsonl` file whose filename begins with your participant ID. Submit this file through the channel specified by the researcher. When using a centralized service, a copy will also be saved on the researcher's computer.

If you modify any selections after exporting, export and submit the updated results again, explicitly indicating that the new file replaces the previous version. The filename includes your participant ID and export timestamp. Please preserve the original filename and file contents.

The complete-results JSONL contains one record per KP with exactly eight fields: `schema_version`, `dataset_id`, `participant_id`, `question_id`, `keypoint_id`, `repository`, `question_type`, and `cognitive_level`. The `.progress.json` backup retains additional metadata needed to restore your progress.

## Pausing, Resuming, and Troubleshooting

- **Completing annotations in multiple sessions.** You may take breaks after completing any portion of the task. Before closing the page, confirm that the upper-right corner displays "Saved" and that no selections are pending.

- **Resuming annotation.** Reopen the page using the same service or local tool and select your original participant ID to restore your saved progress. If the local tool has been stopped, rerun the startup command to continue.

- **Backing up your progress.** Click "Export Progress Backup" to download a `.progress.json` file. When switching devices or independent services, click "Restore Progress" to import the backup under the same participant ID and question set version. For matching KPs, the selections from the backup will be applied. The researcher should help verify that the question set versions are consistent.

- **Handling save failures.** If saving fails, the interface will display a warning and retain your pending selections. Once the connection is restored, click "Retry Save" and wait until the status displays "Saved" before closing the page or switching participant IDs.

- **Handling uncertainty or unclear content.** If you do not fully understand a KP or are unsure which level to select, choose the label that best reflects the background knowledge and explanation depth you need. If you suspect an error in the question or KP itself, send the question ID, KP ID, and a description of the issue to the researcher, and proceed according to their guidance.

- **Selecting the wrong participant ID.** Stop annotating and contact the researcher to verify your ID. Do not continue entering annotations under another participant's ID.

Thank you for your participation!
