# Answer Cognitive Fit: Five-Dimensional Rating Guide


## What You Will Evaluate

You will read two anonymized answers to the same question and independently evaluate how well each answer fits your own understanding needs. For each answer, rate five independent dimensions on a 1–5 scale; a higher score means you are more satisfied with that aspect. The two answers may receive the same scores; you do not need to choose a winner.

**Reference state:** Use your level of understanding and explanation needs before reading either answer to this question as the reference when rating each answer. The two answers may receive the same scores; you do not need to choose a winner. Do not revise the needs you used to rate the first answer merely because the second answer taught you something new. This instruction helps keep the reference state consistent, but cannot fully eliminate order effects.

Before reading the answers to this question, record whether you have previously seen its reference answer or key points: not seen / seen / unsure. This record is used to interpret the effect of prior exposure to the material; it does not affect the answers the system generates for you.

## General Rules

- Judge each dimension independently; the five dimensions do not need to receive the same score.
- Rate according to your own needs, not the needs of an “ideal expert” or a hypothetical novice.
- Answer length, the number of technical terms, and the number of headings do not directly determine a score.
- A score of 3 means you are neither satisfied nor dissatisfied with that dimension; it is not a substitute for “I don't know.”
- Rate the two answers independently. They may receive the same scores, and no particular distribution of high and low scores is required.
- A person's needs may vary across repositories and questions. A score different from someone else's does not mean either person rated incorrectly.
- Do not seek ad hoc help from other people, search engines, or other AI systems. You may pause if you need a break; when resuming, use the same identifier. If the researchers establish shared access conditions, they will specify them separately before formal rating begins.

## The Five Dimensions and Score Anchors

### 1. Explanation Sufficiency

For me to understand this question, does the answer provide sufficient background, explanation, and necessary detail?

| Score | Satisfaction level | Anchor |
|---|---|---|
| 1 | Completely dissatisfied | Essential background, mechanisms, or reasons are seriously missing, and I still cannot understand the core conclusion. |
| 2 | Somewhat dissatisfied | The answer provides some explanation, but important parts are missing and substantial additional information is still needed for understanding. |
| 3 | Neither satisfied nor dissatisfied | I can basically understand the main conclusion, but some necessary background, reasoning, or details remain insufficient. |
| 4 | Somewhat satisfied | The information needed for understanding is largely sufficient, with only a few details still needing to be added. |
| 5 | Completely satisfied | The answer fully meets my understanding needs; the necessary background, mechanisms, and reasons are all adequately explained. |

**Distinguishing note:** Judge by the depth of explanation you need, not by word count. Familiar material need not be repeated; unfamiliar material may still be insufficient if it gives only the conclusion.

### 2. Non-redundancy

Relative to my understanding needs, does the answer avoid unnecessary, repetitive, or irrelevant explanations?

| Score | Satisfaction level | Anchor |
|---|---|---|
| 1 | Completely dissatisfied | There is extensive repetition or irrelevant or unneeded explanation, which clearly hinders finding the information I need. |
| 2 | Somewhat dissatisfied | There is considerable unnecessary content, and I must repeatedly filter it to find the main points. |
| 3 | Neither satisfied nor dissatisfied | Some content is redundant, but I can still find the main points. |
| 4 | Somewhat satisfied | The answer is generally concise, with only a small amount of explanation that could be omitted. |
| 5 | Completely satisfied | There is almost no unnecessary content; both the explanation and its length are appropriate. |

**Distinguishing note:** A short answer does not automatically deserve a high score, and a long answer does not automatically deserve a low score. An answer may be both non-redundant and insufficiently explained; score the two dimensions separately.

### 3. Clarity

Are the answer's organization, wording, and order of reasoning clear and easy for me to follow and understand?

| Score | Satisfaction level | Anchor |
|---|---|---|
| 1 | Completely dissatisfied | The structure is disorganized or the wording is vague, making the explanation very difficult to follow. |
| 2 | Somewhat dissatisfied | Clear jumps, ambiguous references, or organizational problems make the answer difficult to understand. |
| 3 | Neither satisfied nor dissatisfied | The answer is understandable overall, but some paragraphs, terms, or links in the reasoning are not sufficiently clear. |
| 4 | Somewhat satisfied | The structure and expression are clear, with only a few issues that do not affect overall understanding. |
| 5 | Completely satisfied | The hierarchy, references, and links in the reasoning are all clear; it is easy to locate the main points and follow the explanation. |

**Distinguishing note:** Focus on expression and organization. If the answer is hard to understand because it lacks necessary background, that primarily concerns explanation sufficiency; when both problems occur, you may lower both scores separately.

### 4. Cognitive Relevance

Does the answer focus on the knowledge I currently need to understand and place its explanatory emphasis in appropriate areas?

| Score | Satisfaction level | Anchor |
|---|---|---|
| 1 | Completely dissatisfied | The explanatory emphasis almost entirely misses what I need to understand. |
| 2 | Somewhat dissatisfied | Only a small amount of content fits my needs; most of the answer does not target my understanding priorities. |
| 3 | Neither satisfied nor dissatisfied | Some emphases fit my needs, but the answer still clearly overlooks or mismatches my concerns. |
| 4 | Somewhat satisfied | Most explanatory emphases fit my needs, with only minor deviations. |
| 5 | Completely satisfied | The answer accurately focuses on the knowledge I need to understand, and its explanatory emphasis aligns closely with my needs. |

**Distinguishing note:** Judge whether the answer targets your personal understanding priorities, not merely whether it relates to the question's keywords. This dimension concerns the direction of explanation; explanation sufficiency concerns whether the explanation in that direction is sufficient.

### 5. Task Usefulness

Does the answer help me solve the given problem, or make clear how to judge, check, or act next?

| Score | Satisfaction level | Anchor |
|---|---|---|
| 1 | Completely dissatisfied | It provides almost no help in solving the problem or determining the next step. |
| 2 | Somewhat dissatisfied | It provides limited help, but the key uncertainties or obstacles to action remain largely unresolved. |
| 3 | Neither satisfied nor dissatisfied | It provides some help for solving the problem, but substantial additional information is still needed to make a judgment or act. |
| 4 | Somewhat satisfied | It supports solving the problem or determining the next step well, with only a small amount of additional information needed. |
| 5 | Completely satisfied | It directly and effectively helps solve the problem, or clearly identifies reasonable next judgments and actions. |

**Distinguishing note:** An answer to a conceptual or historical-decision question can receive a high task-usefulness score by helping you form a judgment; it need not provide procedural steps. This dimension records perceived help and is not equivalent to actual task success.

## Commonly Confused Cases

| Situation | How to judge |
|---|---|
| The answer is very short and states the conclusion directly. | Someone familiar with the knowledge may find it sufficient; someone who needs background may find it insufficient. Non-redundancy may be high while explanation sufficiency is low. |
| The answer is very long, but every step is something you need. | Do not lower non-redundancy solely because of its length. |
| All content relates to the question, but the part you care about most is mentioned only briefly. | Cognitive relevance and explanation sufficiency may both be affected; judge each by its own definition. |
| The layout is attractive, but the logic jumps or references are unclear. | Do not judge clarity by layout alone. |
| The explanation helps you understand a historical decision but gives no procedural steps. | It may still receive a high task-usefulness score, because forming a judgment is itself helpful. |
| You suspect factual errors, or the answer acknowledges insufficient evidence. | Do not equate fluent writing with correctness. Rate each dimension according to the practical impact of the error or uncertainty and note it in the comments; do not verify it ad hoc. Factual accuracy is reviewed separately. |

## When to Select “Cannot Assess”

Use this option only when you cannot form a judgment for that dimension. If you are dissatisfied with an answer or its explanation is insufficient, you can usually still assign a 1–5 score; do not use “Cannot assess” to avoid a low score. You may select this option independently for different dimensions.

After selecting “Cannot assess,” you must select a reason:

- The question or task lacks sufficient context.
- There is a problem with the answer's display, language, or materials.
- I currently cannot form a judgment for this dimension.
- Other reason (please specify).

When selecting “Other,” you must provide an explanation. “Cannot assess” is not a score of 0 and is not included in the distribution of 1–5 scores. A missing selection, a missing reason, or an unexplained “Other” is incomplete.

## Web Interface Procedure

1. Select the fixed identifier assigned by the researchers, read this guide, and confirm before beginning.
2. Read the question and its context, then record whether you have previously seen this question's reference answer or key points.
3. Read Answer A and rate all five dimensions independently. Hover to view the score anchors, and open the full guide whenever needed.
4. Switch to Answer B and complete the same five ratings independently. Optional comments apply only to the current answer.
5. Selections save automatically; close the page only after you see “Saved.” You may complete the task in batches. To continue, reopen the same entry point and select the same identifier.
6. You may download a progress backup partway through. When switching to an independent service or device, restore it under the same study version and identifier. Restoration replaces the existing selections for the same questions with those in the backup.
7. After all questions are completed and saved, review and confirm submission. Your individual results download automatically, and a copy is also saved on the researcher side. You must reconfirm submission after making changes.

If the connection fails, keep the page open and try again; you may download the “Current window draft” to preserve selections that have not yet been saved. If multiple windows conflict, first download the draft. Then explicitly choose either to keep this window's changes and retry, or to discard pending changes and load the server-side progress. Do not use the same identifier in multiple windows simultaneously.

## About These Ratings

These five dimensions record your subjective experience of how well an answer fits your needs, separately reflecting fit in explanation and use. They do not directly measure learning gains, actual task-completion rates, or factual accuracy, and they do not need to be combined into an overall score. This guide is a rating procedure designed for this study, not a standard scale with completed psychometric validation.
